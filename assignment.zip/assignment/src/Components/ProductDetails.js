import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import ReactImageGallery from "react-image-gallery";
import Rating from '@mui/material/Rating';
import StarIcon from '@mui/icons-material/Star';

import "react-rater/lib/react-rater.css";

const ProductDetails = () => {
    const { id } = useParams();
    const [settings1, setProducts] = useState([]);
    const [imagesfor, setFormattedImages] = useState([]);
    const [value, setvalue] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch(`https://dummyjson.com/products/${id}`);
                if (!response.ok) {
                    throw new Error('Failed to fetch data');
                }
                const data = await response.json();
                setProducts(data);
                const formattedImages = data.images.map(url => ({
                    original: url,
                    thumbnail: url, // Using the same URL for thumbnail
                }));
                setFormattedImages(formattedImages);
                setvalue(data.rating)
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };
        fetchData();

    }, [id]);
    const productDetailItem = {
        images: [
            {
                original:
                    "https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=600",
                thumbnail:
                    "https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=600",
            },
            {
                original:
                    "https://images.pexels.com/photos/1667088/pexels-photo-1667088.jpeg?auto=compress&cs=tinysrgb&w=600",
                thumbnail:
                    "https://images.pexels.com/photos/1667088/pexels-photo-1667088.jpeg?auto=compress&cs=tinysrgb&w=600",
            },
            {
                original:
                    "https://images.pexels.com/photos/2697787/pexels-photo-2697787.jpeg?auto=compress&cs=tinysrgb&w=600",
                thumbnail:
                    "https://images.pexels.com/photos/2697787/pexels-photo-2697787.jpeg?auto=compress&cs=tinysrgb&w=600",
            },
            {
                original:
                    "https://images.pexels.com/photos/3373736/pexels-photo-3373736.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
                thumbnail:
                    "https://images.pexels.com/photos/3373736/pexels-photo-3373736.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
            },
            {
                original:
                    "https://images.pexels.com/photos/3910071/pexels-photo-3910071.jpeg?auto=compress&cs=tinysrgb&w=600",
                thumbnail:
                    "https://images.pexels.com/photos/3910071/pexels-photo-3910071.jpeg?auto=compress&cs=tinysrgb&w=600",
            },
        ],
        title: "BIG ITALIAN SOFA",
        reviews: "150",
        availability: true,
        brand: "apex",
        category: "Sofa",
        sku: "BE45VGTRK",
        price: 450,
        previousPrice: 599,
        description:
            "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem exercitationem voluptate sint eius ea assumenda provident eos repellendus qui neque! Velit ratione illo maiores voluptates commodi eaque illum, laudantium non!",
        size: ["XS", "S", "M", "L", "XL"],
        color: ["gray", "violet", "red"],
    };

    return (
        <section className="container flex-grow max-w-[120px] border-b py-5 lg:grid lg:grid-cols-2 lg:py-10">
            {/* image gallery */}
            <div className="container mx-auto px-4">
                <ReactImageGallery
                    showBullets={false}
                    showFullscreenButton={false}
                    showPlayButton={false}
                    items={imagesfor}
                    className="w-full h-auto" // Adjust width to full and height to auto
                />
            </div>

            {/* description  */}

            <div className="mx-auto px-5 lg:px-5">
                <h2 className="pt-3 text-2xl font-bold lg:pt-0">
                    {settings1.title}
                </h2>
                <p className="font-bold">
                    Brand: <span className="font-normal">{settings1.brand}</span>
                </p>
                <p className="font-bold">
                    Cathegory:{" "}
                    <span className="font-normal">{settings1.category}</span>
                </p>
                <p className="font-bold">
                    STOCK: <span className="font-normal">{settings1.stock}</span>
                </p>
                <p className="mt-4 text-4xl font-bold text-violet-900">
                    PRICE: ${settings1.price}{","} DISCOUNT %: {settings1.discountPercentage}
                </p>
                <p className="pt-5 text-sm leading-5 text-gray-500">
                    {settings1.description}
                </p>
                
                <Rating
                    name="text-feedback"
                    value={value}
                    readOnly
                    precision={0.5}
                    emptyIcon={<StarIcon style={{ opacity: 0.55 }} fontSize="inherit" />}
                />
            </div>
        </section>
    );
};

export default ProductDetails;