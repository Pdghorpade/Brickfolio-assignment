import React, { useEffect, useState } from 'react';
import Card from '@mui/material/Card';
import CardMedia from '@mui/material/CardMedia';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { Link } from 'react-router-dom';

export default function RecipeReviewCard(data) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) =>
        prevIndex === data.product.images.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000); // Change image every 3 seconds, adjust interval as needed

    return () => clearInterval(interval);
  }, [data.product.images]);

console.log(data);
  return (
    <Card sx={{ minWidth: 345, maxWidth: 345, paddingTop: '20px' }}>
    <Link to={`/products/${data.product.id}`}>
      <CardMedia
        component="img"
        height="194"
        image={data.product.images[currentImageIndex]}
        alt={data.product.brand}
      />
      <CardContent>
        <Typography variant="body2" color="text.secondary">
          Brand: {data.product.brand}
        </Typography>
      </CardContent>
    </Link>
  </Card>
  );
}
