import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import RecipeReviewCard from './RecipeReviewCard';
export const Homepage = () => {
    const { id } = useParams();
    const [settings, setProducts] = useState(null);
  useEffect(() => {
    fetch(`https://dummyjson.com/products/category/${id}`)
      .then(response => response.json())
      .then(data => setProducts(data.products));
  }, [id]);
  return (
    <div className='container' style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', paddingTop: '20px'  }}>
  {settings ? (
    settings.map((product, index) => (
      <RecipeReviewCard key={product.id} product={product} style={{ flex: '0 0 calc(33.33% - 20px)' }} />
    ))
  ) : (
    <p>Loading...</p>
  )}
</div>

  )
}
