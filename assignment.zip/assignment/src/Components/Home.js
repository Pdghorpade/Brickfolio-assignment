import React, { useEffect, useState } from 'react';
import RecipeReviewCard from './RecipeReviewCard';
export const Home = () => {
    const [settings, setProducts] = useState(null);
  useEffect(() => {
    fetch(`https://dummyjson.com/products`)
      .then(response => response.json())
      .then(data => setProducts(data.products));
  }, []);
  return (
    <div className='container' style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', paddingTop: '20px'  }}>
  {settings ? (
    settings.map((product, index) => (
      <RecipeReviewCard key={product.id} product={product} style={{ flex: '0 0 calc(33.33% - 20px)' }} />
    ))
  ) : (
    <p>Loading...</p>
  )}
</div>

  )
}
