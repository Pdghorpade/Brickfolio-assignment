import './App.css';
import { BrowserRouter as Router } from 'react-router-dom';
import {  Route,Routes } from 'react-router-dom';

import ResponsiveAppBar from './Components/ResponsiveAppBar';
import RecipeReviewCard from './Components/RecipeReviewCard';
import { Homepage } from './Components/Homepage';
import ProductDetails from './Components/ProductDetails';
import { Home } from './Components/Home';

function App() {
  return (
    <Router>
        <ResponsiveAppBar/>
        
        {/* <ProductDetails/> */}
        {/* <RecipeReviewCard data={"abc"}/> */}
        <Routes>
          <Route path="/" exact element={<Home/>} />
          <Route path="/products/category/:id" element={<Homepage/>} />
          <Route path="/products/:id" element={<ProductDetails/>} />
          </Routes>
    </Router>
  );
}

export default App;
